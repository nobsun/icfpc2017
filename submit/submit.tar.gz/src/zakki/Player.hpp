#pragma once
#include "Game.hpp"

void initPlayer();
JMove genmove(Game& game, int player);
