# hs

$ cd hs
$ cabal build

